# Revision memo: academic interlocutors and Mobley live-case independence

## 1. Academic dialogue and question presented

The Introduction now names four concrete positions in the AI-liability merits debate:

- Anat Lior: strict liability for AI-inflicted damages.
- Zachary Henderson: rejection of categorical strict liability in favor of ordinary tort, narrow legislation, and insurance.
- Catherine Sharkey: products liability as the most promising AI framework.
- Ketan Ramakrishnan: negligence as the principal doctrinal foundation for foundation-model liability.

The revised paragraph then distinguishes the Article's access question from that merits question and states that the merits firewall leaves the substantive disagreement intact. This completes all three question-presented tests: the competing positions are stated, the questions are distinguished, and the access question is shown to be independently necessary.

## 2. II.G merits-firewall answer

The closing paragraph of II.G now expressly connects the Erie/Hanna allocation to the named scholarly disagreement: the state access entitlement supplies a record on which the governing liability rule can operate but neither selects that rule nor changes its elements.

## 3. Mobley live-case independence

Part III now states globally, before the applications begin, that the Mobley analysis is independent of later decertification, dismissal, merits judgment, appellate disposition, or settlement. Each cited order is used only for its procedural posture and the record-allocation problem it documents. The footnote fixes the docket cutoff at July 2, 2026.

The Mobley subsection no longer says that a "pending docket reveals" the Article's four problems. It says that the cited orders expose recurring record-allocation problems, removing dependence on the litigation's eventual outcome.

## Files changed

- `article/01-introduction.tex`
- `article/03-front-door-rule.tex`
- `article/04-rule-in-operation.tex`
- `what-is-ai-for-courts.bib`

A validation pass also replaced one preexisting instance of the prohibited phrase `falls short` with specification grammar (`does not constitute legally sufficient notice`).

The abstract and conclusion are unchanged. Neither is the correct location for naming the merits interlocutors or fencing an active docket; the Introduction, II.G, and Part III opening now perform those jobs directly.

## Validation

- All new citation keys resolve exactly once.
- Biber parsed the bibliography; stock-datamodel warnings concern preexisting custom legal entry types.
- All seven section files passed a 51-page LaTeX syntax build under a compatibility harness. The submission class itself was not available in the runtime, so this was not a journal-class layout build.
- The manuscript-wide prohibited-grammar scan returned no remaining hits for the specified phrases.
